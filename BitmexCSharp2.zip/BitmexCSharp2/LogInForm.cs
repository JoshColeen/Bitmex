﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BitmexCSharp2
{
    public partial class LogInForm : Form
    {
        public LogInForm()
        {
            InitializeComponent();
        }

        private void Cancelbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void LogInButton_Click(object sender, EventArgs e)
        {
            BitmexForm bf = new BitmexForm();
            bf.setBitmexApiSecret(apiKeyTextbox.Text, secretTextbox.Text,NetworkList.Text);
            String reply = bf.isValid();
            List<string> items = reply.Split('"').ToList<string>();
            if (items.ElementAt(1) == "error")
            {
                this.Text = "Log in to bitmex bot : Authentication failed!";
            }
            else
            {
                bf.Show();
                this.Hide();
            }
            //MessageBox.Show(reply);
        }

        private void LogInForm_Load(object sender, EventArgs e)
        {
            NetworkList.SelectedIndex = 0;
        }
    }
}
