﻿namespace BitmexCSharp2
{
    partial class LogInForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LogInForm));
            this.label1 = new System.Windows.Forms.Label();
            this.apiKeyTextbox = new System.Windows.Forms.TextBox();
            this.secretTextbox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.LogInButton = new System.Windows.Forms.Button();
            this.Cancelbutton = new System.Windows.Forms.Button();
            this.NetworkList = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "API Key";
            // 
            // apiKeyTextbox
            // 
            this.apiKeyTextbox.Location = new System.Drawing.Point(61, 44);
            this.apiKeyTextbox.Name = "apiKeyTextbox";
            this.apiKeyTextbox.Size = new System.Drawing.Size(360, 20);
            this.apiKeyTextbox.TabIndex = 1;
            // 
            // secretTextbox
            // 
            this.secretTextbox.Location = new System.Drawing.Point(61, 70);
            this.secretTextbox.Name = "secretTextbox";
            this.secretTextbox.Size = new System.Drawing.Size(360, 20);
            this.secretTextbox.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "API Secret";
            // 
            // LogInButton
            // 
            this.LogInButton.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.LogInButton.Location = new System.Drawing.Point(86, 96);
            this.LogInButton.Name = "LogInButton";
            this.LogInButton.Size = new System.Drawing.Size(103, 23);
            this.LogInButton.TabIndex = 4;
            this.LogInButton.Text = "Log In";
            this.LogInButton.UseVisualStyleBackColor = true;
            this.LogInButton.Click += new System.EventHandler(this.LogInButton_Click);
            // 
            // Cancelbutton
            // 
            this.Cancelbutton.Location = new System.Drawing.Point(238, 96);
            this.Cancelbutton.Name = "Cancelbutton";
            this.Cancelbutton.Size = new System.Drawing.Size(103, 23);
            this.Cancelbutton.TabIndex = 5;
            this.Cancelbutton.Text = "Cancel";
            this.Cancelbutton.UseVisualStyleBackColor = true;
            this.Cancelbutton.Click += new System.EventHandler(this.Cancelbutton_Click);
            // 
            // NetworkList
            // 
            this.NetworkList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.NetworkList.FormattingEnabled = true;
            this.NetworkList.Items.AddRange(new object[] {
            "TestNet",
            "RealNet"});
            this.NetworkList.Location = new System.Drawing.Point(61, 12);
            this.NetworkList.Name = "NetworkList";
            this.NetworkList.Size = new System.Drawing.Size(71, 21);
            this.NetworkList.TabIndex = 13;
            // 
            // LogInForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 123);
            this.Controls.Add(this.NetworkList);
            this.Controls.Add(this.Cancelbutton);
            this.Controls.Add(this.LogInButton);
            this.Controls.Add(this.secretTextbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.apiKeyTextbox);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LogInForm";
            this.Text = "Log in to bitmex bot";
            this.Load += new System.EventHandler(this.LogInForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox apiKeyTextbox;
        private System.Windows.Forms.TextBox secretTextbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button LogInButton;
        private System.Windows.Forms.Button Cancelbutton;
        private System.Windows.Forms.ComboBox NetworkList;
    }
}

