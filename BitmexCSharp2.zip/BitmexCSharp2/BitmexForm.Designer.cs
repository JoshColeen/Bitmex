﻿namespace BitmexCSharp2
{
    partial class BitmexForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

          /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BitmexForm));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ExitButton = new System.Windows.Forms.Button();
            this.TradeGroupBox = new System.Windows.Forms.GroupBox();
            this.ActionButton = new System.Windows.Forms.Button();
            this.ActionList = new System.Windows.Forms.ComboBox();
            this.BuyButton = new System.Windows.Forms.Button();
            this.SellButton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BitmexSay = new System.Windows.Forms.TextBox();
            this.Strategy2GroupBox = new System.Windows.Forms.GroupBox();
            this.cumQtyTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.stop1Button = new System.Windows.Forms.Button();
            this.start1Button = new System.Windows.Forms.Button();
            this.CurPriceTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SideList = new System.Windows.Forms.ComboBox();
            this.timerUpDown = new System.Windows.Forms.NumericUpDown();
            this.Qty = new System.Windows.Forms.NumericUpDown();
            this.OrderTypeList = new System.Windows.Forms.ComboBox();
            this.SymbolList = new System.Windows.Forms.ComboBox();
            this.LeverageList = new System.Windows.Forms.ComboBox();
            this.rateTimer1 = new System.Windows.Forms.Timer(this.components);
            this.status = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.CancelAllOrdersButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.X = new System.Windows.Forms.NumericUpDown();
            this.OverOrdersButton = new System.Windows.Forms.Button();
            this.MinOrderSize = new System.Windows.Forms.NumericUpDown();
            this.Stop2Button = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.Start2Button = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.MainTimer = new System.Windows.Forms.Timer(this.components);
            this.CloseAllPositionsButton = new System.Windows.Forms.Button();
            this.testMailButton = new System.Windows.Forms.Button();
            this.rateTimer2 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.TradeGroupBox.SuspendLayout();
            this.Strategy2GroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.timerUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Qty)).BeginInit();
            this.status.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MinOrderSize)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(86, 59);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(621, 7);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(71, 21);
            this.ExitButton.TabIndex = 1;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // TradeGroupBox
            // 
            this.TradeGroupBox.Controls.Add(this.ActionButton);
            this.TradeGroupBox.Controls.Add(this.ActionList);
            this.TradeGroupBox.Controls.Add(this.BuyButton);
            this.TradeGroupBox.Controls.Add(this.SellButton);
            this.TradeGroupBox.Location = new System.Drawing.Point(3, 70);
            this.TradeGroupBox.Name = "TradeGroupBox";
            this.TradeGroupBox.Size = new System.Drawing.Size(210, 121);
            this.TradeGroupBox.TabIndex = 8;
            this.TradeGroupBox.TabStop = false;
            this.TradeGroupBox.Text = "Manual Trade";
            this.TradeGroupBox.Enter += new System.EventHandler(this.TradeGroupBox_Enter);
            // 
            // ActionButton
            // 
            this.ActionButton.Location = new System.Drawing.Point(69, 75);
            this.ActionButton.Name = "ActionButton";
            this.ActionButton.Size = new System.Drawing.Size(75, 21);
            this.ActionButton.TabIndex = 17;
            this.ActionButton.Text = "Do Action";
            this.ActionButton.UseVisualStyleBackColor = true;
            this.ActionButton.Click += new System.EventHandler(this.ActionButton_Click);
            // 
            // ActionList
            // 
            this.ActionList.Cursor = System.Windows.Forms.Cursors.Default;
            this.ActionList.FormattingEnabled = true;
            this.ActionList.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.ActionList.Items.AddRange(new object[] {
            "GET/last order",
            "GET/last order orderID",
            "Display Recent Trade Price",
            "Order Amend",
            "Get 5 Level Order Book",
            "Liquidation",
            "Get Open Position",
            "Get Open Position Quantity",
            "Close One Position",
            "Get Open Position maintMargin",
            "Add Margin To Position",
            "Margin Balance Info",
            "Get Entry Price",
            "Wallet Ballance",
            "Reduceonly",
            "PostOrderClose",
            "PostOrderParticipateDoNotInitiate"});
            this.ActionList.Location = new System.Drawing.Point(8, 48);
            this.ActionList.Name = "ActionList";
            this.ActionList.Size = new System.Drawing.Size(191, 21);
            this.ActionList.TabIndex = 16;
            this.ActionList.SelectedIndexChanged += new System.EventHandler(this.ActionList_SelectedIndexChanged);
            // 
            // BuyButton
            // 
            this.BuyButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.BuyButton.Location = new System.Drawing.Point(8, 19);
            this.BuyButton.Name = "BuyButton";
            this.BuyButton.Size = new System.Drawing.Size(75, 23);
            this.BuyButton.TabIndex = 14;
            this.BuyButton.Text = "Buy";
            this.BuyButton.UseVisualStyleBackColor = false;
            this.BuyButton.Click += new System.EventHandler(this.BuyButton_Click);
            // 
            // SellButton
            // 
            this.SellButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.SellButton.Location = new System.Drawing.Point(124, 18);
            this.SellButton.Name = "SellButton";
            this.SellButton.Size = new System.Drawing.Size(75, 23);
            this.SellButton.TabIndex = 9;
            this.SellButton.Text = "Sell";
            this.SellButton.UseVisualStyleBackColor = false;
            this.SellButton.Click += new System.EventHandler(this.SellButton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(257, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Leverage";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1, 361);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Bitmex say:";
            // 
            // BitmexSay
            // 
            this.BitmexSay.Location = new System.Drawing.Point(3, 197);
            this.BitmexSay.Multiline = true;
            this.BitmexSay.Name = "BitmexSay";
            this.BitmexSay.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.BitmexSay.Size = new System.Drawing.Size(698, 272);
            this.BitmexSay.TabIndex = 10;
            this.BitmexSay.TextChanged += new System.EventHandler(this.BitmexSay_TextChanged);
            // 
            // Strategy2GroupBox
            // 
            this.Strategy2GroupBox.Controls.Add(this.cumQtyTextBox);
            this.Strategy2GroupBox.Controls.Add(this.label2);
            this.Strategy2GroupBox.Controls.Add(this.stop1Button);
            this.Strategy2GroupBox.Controls.Add(this.start1Button);
            this.Strategy2GroupBox.Controls.Add(this.CurPriceTextBox);
            this.Strategy2GroupBox.Controls.Add(this.label5);
            this.Strategy2GroupBox.Location = new System.Drawing.Point(219, 70);
            this.Strategy2GroupBox.Name = "Strategy2GroupBox";
            this.Strategy2GroupBox.Size = new System.Drawing.Size(151, 121);
            this.Strategy2GroupBox.TabIndex = 11;
            this.Strategy2GroupBox.TabStop = false;
            this.Strategy2GroupBox.Text = "Strategy 1 Auto trading";
            // 
            // cumQtyTextBox
            // 
            this.cumQtyTextBox.Enabled = false;
            this.cumQtyTextBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.cumQtyTextBox.Location = new System.Drawing.Point(54, 42);
            this.cumQtyTextBox.Name = "cumQtyTextBox";
            this.cumQtyTextBox.Size = new System.Drawing.Size(91, 20);
            this.cumQtyTextBox.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Filled";
            // 
            // stop1Button
            // 
            this.stop1Button.Location = new System.Drawing.Point(80, 96);
            this.stop1Button.Name = "stop1Button";
            this.stop1Button.Size = new System.Drawing.Size(65, 20);
            this.stop1Button.TabIndex = 14;
            this.stop1Button.Text = "Stop 1";
            this.stop1Button.UseVisualStyleBackColor = true;
            this.stop1Button.Click += new System.EventHandler(this.stop1Button_Click);
            // 
            // start1Button
            // 
            this.start1Button.Location = new System.Drawing.Point(6, 95);
            this.start1Button.Name = "start1Button";
            this.start1Button.Size = new System.Drawing.Size(68, 20);
            this.start1Button.TabIndex = 13;
            this.start1Button.Text = "Start1";
            this.start1Button.UseVisualStyleBackColor = true;
            this.start1Button.Click += new System.EventHandler(this.start1Button_Click);
            // 
            // CurPriceTextBox
            // 
            this.CurPriceTextBox.Enabled = false;
            this.CurPriceTextBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.CurPriceTextBox.Location = new System.Drawing.Point(54, 18);
            this.CurPriceTextBox.Name = "CurPriceTextBox";
            this.CurPriceTextBox.Size = new System.Drawing.Size(91, 20);
            this.CurPriceTextBox.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Price";
            // 
            // SideList
            // 
            this.SideList.Cursor = System.Windows.Forms.Cursors.Default;
            this.SideList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SideList.FormattingEnabled = true;
            this.SideList.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.SideList.Items.AddRange(new object[] {
            "Buy",
            "Sell"});
            this.SideList.Location = new System.Drawing.Point(9, 69);
            this.SideList.Name = "SideList";
            this.SideList.Size = new System.Drawing.Size(73, 21);
            this.SideList.TabIndex = 12;
            // 
            // timerUpDown
            // 
            this.timerUpDown.Location = new System.Drawing.Point(9, 43);
            this.timerUpDown.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.timerUpDown.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.timerUpDown.Name = "timerUpDown";
            this.timerUpDown.Size = new System.Drawing.Size(73, 20);
            this.timerUpDown.TabIndex = 15;
            this.timerUpDown.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.timerUpDown.ValueChanged += new System.EventHandler(this.timerUpDown_ValueChanged);
            // 
            // Qty
            // 
            this.Qty.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.Qty.Location = new System.Drawing.Point(105, 33);
            this.Qty.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.Qty.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.Qty.Name = "Qty";
            this.Qty.Size = new System.Drawing.Size(71, 20);
            this.Qty.TabIndex = 10;
            this.Qty.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.Qty.ValueChanged += new System.EventHandler(this.Qty_ValueChanged);
            // 
            // OrderTypeList
            // 
            this.OrderTypeList.Cursor = System.Windows.Forms.Cursors.Default;
            this.OrderTypeList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.OrderTypeList.FormattingEnabled = true;
            this.OrderTypeList.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.OrderTypeList.Items.AddRange(new object[] {
            "Market",
            "Limit"});
            this.OrderTypeList.Location = new System.Drawing.Point(105, 7);
            this.OrderTypeList.Name = "OrderTypeList";
            this.OrderTypeList.Size = new System.Drawing.Size(71, 21);
            this.OrderTypeList.TabIndex = 11;
            this.OrderTypeList.SelectedIndexChanged += new System.EventHandler(this.OrderTypeList_SelectedIndexChanged);
            // 
            // SymbolList
            // 
            this.SymbolList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SymbolList.FormattingEnabled = true;
            this.SymbolList.Items.AddRange(new object[] {
            "XBTUSD",
            "ADAM19",
            "BCHM19",
            "EOSM19",
            "ETHXBT",
            "LTCM19",
            "TRXM19",
            "XRPM19"});
            this.SymbolList.Location = new System.Drawing.Point(182, 7);
            this.SymbolList.Name = "SymbolList";
            this.SymbolList.Size = new System.Drawing.Size(71, 21);
            this.SymbolList.TabIndex = 13;
            this.SymbolList.SelectedIndexChanged += new System.EventHandler(this.SymbolList_SelectedIndexChanged);
            // 
            // LeverageList
            // 
            this.LeverageList.Cursor = System.Windows.Forms.Cursors.Default;
            this.LeverageList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LeverageList.FormattingEnabled = true;
            this.LeverageList.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.LeverageList.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "5",
            "10",
            "25",
            "50",
            "100"});
            this.LeverageList.Location = new System.Drawing.Point(308, 7);
            this.LeverageList.Name = "LeverageList";
            this.LeverageList.Size = new System.Drawing.Size(71, 21);
            this.LeverageList.TabIndex = 16;
            this.LeverageList.SelectedIndexChanged += new System.EventHandler(this.LeverageList_SelectedIndexChanged);
            // 
            // rateTimer1
            // 
            this.rateTimer1.Interval = 2000;
            this.rateTimer1.Tick += new System.EventHandler(this.RateTimer_Tick);
            // 
            // status
            // 
            this.status.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.status.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.status.Location = new System.Drawing.Point(0, 472);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(712, 22);
            this.status.TabIndex = 18;
            this.status.Text = "status";
            this.status.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.status_ItemClicked);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.toolStripStatusLabel2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(0, 17);
            // 
            // CancelAllOrdersButton
            // 
            this.CancelAllOrdersButton.Location = new System.Drawing.Point(407, 7);
            this.CancelAllOrdersButton.Name = "CancelAllOrdersButton";
            this.CancelAllOrdersButton.Size = new System.Drawing.Size(107, 20);
            this.CancelAllOrdersButton.TabIndex = 19;
            this.CancelAllOrdersButton.Text = "Cancel All Orders";
            this.CancelAllOrdersButton.UseVisualStyleBackColor = true;
            this.CancelAllOrdersButton.Click += new System.EventHandler(this.CancelAllOrdersButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.X);
            this.groupBox1.Controls.Add(this.OverOrdersButton);
            this.groupBox1.Controls.Add(this.MinOrderSize);
            this.groupBox1.Controls.Add(this.Stop2Button);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.Start2Button);
            this.groupBox1.Location = new System.Drawing.Point(509, 70);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(157, 121);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Strategy 2 Auto Trading";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "X";
            // 
            // X
            // 
            this.X.Location = new System.Drawing.Point(76, 43);
            this.X.Name = "X";
            this.X.Size = new System.Drawing.Size(72, 20);
            this.X.TabIndex = 20;
            this.X.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // OverOrdersButton
            // 
            this.OverOrdersButton.Location = new System.Drawing.Point(8, 70);
            this.OverOrdersButton.Name = "OverOrdersButton";
            this.OverOrdersButton.Size = new System.Drawing.Size(139, 23);
            this.OverOrdersButton.TabIndex = 19;
            this.OverOrdersButton.Text = "Over Orders";
            this.OverOrdersButton.UseVisualStyleBackColor = true;
            this.OverOrdersButton.Click += new System.EventHandler(this.OverOrdersButton_Click);
            // 
            // MinOrderSize
            // 
            this.MinOrderSize.Location = new System.Drawing.Point(75, 19);
            this.MinOrderSize.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.MinOrderSize.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.MinOrderSize.Name = "MinOrderSize";
            this.MinOrderSize.Size = new System.Drawing.Size(73, 20);
            this.MinOrderSize.TabIndex = 17;
            this.MinOrderSize.Value = new decimal(new int[] {
            400000,
            0,
            0,
            0});
            // 
            // Stop2Button
            // 
            this.Stop2Button.Location = new System.Drawing.Point(80, 97);
            this.Stop2Button.Name = "Stop2Button";
            this.Stop2Button.Size = new System.Drawing.Size(67, 20);
            this.Stop2Button.TabIndex = 16;
            this.Stop2Button.Text = "Stop 2";
            this.Stop2Button.UseVisualStyleBackColor = true;
            this.Stop2Button.Click += new System.EventHandler(this.Stop2Button_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 13);
            this.label7.TabIndex = 18;
            this.label7.Text = "Min Order Size";
            // 
            // Start2Button
            // 
            this.Start2Button.Location = new System.Drawing.Point(8, 97);
            this.Start2Button.Name = "Start2Button";
            this.Start2Button.Size = new System.Drawing.Size(68, 20);
            this.Start2Button.TabIndex = 15;
            this.Start2Button.Text = "Start 2";
            this.Start2Button.UseVisualStyleBackColor = true;
            this.Start2Button.Click += new System.EventHandler(this.Start2Button_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.timerUpDown);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.SideList);
            this.groupBox2.Location = new System.Drawing.Point(376, 70);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(117, 121);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Auto Trade Setting";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Time Interval(ms)";
            // 
            // MainTimer
            // 
            this.MainTimer.Interval = 1000;
            this.MainTimer.Tick += new System.EventHandler(this.MainTimer_Tick);
            // 
            // CloseAllPositionsButton
            // 
            this.CloseAllPositionsButton.Location = new System.Drawing.Point(407, 33);
            this.CloseAllPositionsButton.Name = "CloseAllPositionsButton";
            this.CloseAllPositionsButton.Size = new System.Drawing.Size(106, 20);
            this.CloseAllPositionsButton.TabIndex = 22;
            this.CloseAllPositionsButton.Text = "Close All Positions";
            this.CloseAllPositionsButton.UseVisualStyleBackColor = true;
            this.CloseAllPositionsButton.Click += new System.EventHandler(this.CloseAllPositionsButton_Click);
            // 
            // testMailButton
            // 
            this.testMailButton.Location = new System.Drawing.Point(621, 37);
            this.testMailButton.Name = "testMailButton";
            this.testMailButton.Size = new System.Drawing.Size(71, 20);
            this.testMailButton.TabIndex = 23;
            this.testMailButton.Text = "Test Mail";
            this.testMailButton.UseVisualStyleBackColor = true;
            this.testMailButton.Click += new System.EventHandler(this.testMailButton_Click);
            // 
            // rateTimer2
            // 
            this.rateTimer2.Interval = 2000;
            this.rateTimer2.Tick += new System.EventHandler(this.rateTimer2_Tick);
            // 
            // BitmexForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(712, 494);
            this.ControlBox = false;
            this.Controls.Add(this.testMailButton);
            this.Controls.Add(this.CloseAllPositionsButton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.CancelAllOrdersButton);
            this.Controls.Add(this.status);
            this.Controls.Add(this.Strategy2GroupBox);
            this.Controls.Add(this.LeverageList);
            this.Controls.Add(this.BitmexSay);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TradeGroupBox);
            this.Controls.Add(this.SymbolList);
            this.Controls.Add(this.Qty);
            this.Controls.Add(this.OrderTypeList);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BitmexForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BitmexForm";
            this.Load += new System.EventHandler(this.BitmexForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.TradeGroupBox.ResumeLayout(false);
            this.Strategy2GroupBox.ResumeLayout(false);
            this.Strategy2GroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.timerUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Qty)).EndInit();
            this.status.ResumeLayout(false);
            this.status.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MinOrderSize)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.GroupBox TradeGroupBox;
        private System.Windows.Forms.Button SellButton;
        private System.Windows.Forms.Button BuyButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox BitmexSay;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox Strategy2GroupBox;
        private System.Windows.Forms.ComboBox SideList;
        private System.Windows.Forms.NumericUpDown Qty;
        private System.Windows.Forms.ComboBox OrderTypeList;
        private System.Windows.Forms.ComboBox SymbolList;
        private System.Windows.Forms.ComboBox LeverageList;
        private System.Windows.Forms.Button stop1Button;
        private System.Windows.Forms.Button start1Button;
        private System.Windows.Forms.NumericUpDown timerUpDown;
        public System.Windows.Forms.Timer rateTimer1;
        private System.Windows.Forms.StatusStrip status;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Button ActionButton;
        private System.Windows.Forms.ComboBox ActionList;
        private System.Windows.Forms.TextBox CurPriceTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button CancelAllOrdersButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Stop2Button;
        private System.Windows.Forms.Button Start2Button;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Timer MainTimer;
        private System.Windows.Forms.NumericUpDown MinOrderSize;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button CloseAllPositionsButton;
        private System.Windows.Forms.Button OverOrdersButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown X;
        private System.Windows.Forms.Button testMailButton;
        public System.Windows.Forms.Timer rateTimer2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.TextBox cumQtyTextBox;
        private System.Windows.Forms.Label label2;
    }
}