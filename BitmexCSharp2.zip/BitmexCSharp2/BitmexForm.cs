﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;
//using Office = Microsoft.Office.Core;

namespace BitmexCSharp2
{
    public partial class BitmexForm : Form
    {
        private BitmexAPI bitmexApi;
        private bool autoTrading1;
        private bool autoTrading2;
        private long elapsedTime1;
        private long elapsedTime2;
        private string strategy1_orderID;
        private string strategy2_orderID;

        public BitmexForm()
        {
            InitializeComponent();
            bitmexApi = new BitmexAPI();
            autoTrading1 = false;
            elapsedTime1 = 0;
            autoTrading2 = false;
            elapsedTime2 = 0;
            strategy1_orderID = "";
            strategy2_orderID = "";
        }
        public string isValid()
        {
            return bitmexApi.GetLastOrder("", "");
        }
        public void setBitmexApiSecret(string apikey,string secret, string network)
        {
            this.bitmexApi.apiKey = apikey;
            this.bitmexApi.apiSecret = secret;
            if (network == "TestNet")
            {
                this.bitmexApi.domain = "https://testnet.bitmex.com";
            }
            else if (network == "RealNet")
            {
                this.bitmexApi.domain = "https://www.bitmex.com/";
            }
            else
            {
                System.Environment.Exit(0);
            }
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.ExitThread();
        }

        private void apiKey_TextChanged(object sender, EventArgs e)
        {
            //bitmexApi.apiKey = sender.ToString();
            //MessageBox.Show("API key changed!", bitmexApi.apiKey);
        }

        private void apiSecret_TextChanged(object sender, EventArgs e)
        {
            //bitmexApi.apiSecret = sender.ToString();
            //MessageBox.Show("API secret changed!", bitmexApi.apiSecret);
        }

        private void BitmexForm_Load(object sender, EventArgs e)
        {
            OrderTypeList.SelectedIndex = 1;
            SymbolList.SelectedIndex = 0;
            LeverageList.SelectedIndex = 2;
            SideList.SelectedIndex = 0;
            ActionList.SelectedIndex = 0;
        }

        private void BuyButton_Click(object sender, EventArgs e)
        {
            //string bitmexKey = "azUkIGbe2yJkvWYiGDQsM7-f";
            //string bitmexSecret = "KX5fLBCjW_eL3STV_chjFvmTZnrHXdtZQwxyl2tlhry5YrKG";
            //BitmexAPI bitmex = new BitmexAPI(bitmexKey, bitmexSecret);
            //public string PostOrders(String symbol, String side, String qty, String type)
            String symbol = SymbolList.Text;
            String side = "Buy";
            String qty = Qty.Value.ToString();
            String type = OrderTypeList.Text;
            BitmexSay.Text = bitmexApi.PostOrders(symbol,side,qty,type);
            //MessageBox.Show(orders, "ff");
        }

        private void SellButton_Click(object sender, EventArgs e)
        {
            String symbol = SymbolList.Text;
            String side = "Sell";
            String qty = Qty.Value.ToString();
            String type = OrderTypeList.Text;
            BitmexSay.Text = bitmexApi.PostOrders(symbol, side, qty, type);
        }

        private void LeverageList_SelectedIndexChanged(object sender, EventArgs e)
        {
            BitmexSay.Text =bitmexApi.setLeverage(SymbolList.Text,LeverageList.Text);
        }

        private void RateTimer_Tick(object sender, EventArgs e)
        {
            //MessageBox.Show("",rateTimer.Interval.ToString());
            if (this.autoTrading1==false)
            {
                return;
            }
            elapsedTime1 += rateTimer1.Interval/1000;
            long second = elapsedTime1;
            long minute = second / 60;
            second = second % 60;
            long hour = minute / 60;
            minute = minute % 60;
            toolStripStatusLabel1.Text = "Strategy1 "+" Auto trading " + hour.ToString()+":"+minute.ToString()+":"+second.ToString();
            if (this.autoTrading1 == true)
            {
                BitmexSay.Text = bitmexApi.GetOrderByID(this.strategy1_orderID);
                List<string> items = BitmexSay.Text.Split('"').ToList<string>();
                if (items[1] == "error")
                {
                    rateTimer1.Stop();
                    this.autoTrading1 = false;
                    toolStripStatusLabel1.Text += " ...Error occured... Stopped!";
                    status.Refresh();
                    this.strategy1_orderID = "";
                    this.elapsedTime1 = 0;
                    CurPriceTextBox.Text = "";
                    return;
                }
                cumQtyTextBox.Text = items[88].Substring(1, items[88].Length-2);
                String ordStatus = items[69];
                if (ordStatus == "Filled")
                {
                    rateTimer1.Stop();
                    this.autoTrading1 =false;
                    toolStripStatusLabel1.Text += " ...Order filled... Stopped!";
                    status.Refresh();
                    this.strategy1_orderID = "";
                    this.elapsedTime1 = 0;
                    String symbol = items[17];
                    String side = items[21];
                    String orderQty = items[26].Substring(1, items[26].Length - 2);
                    //String price = items[28].Substring(1, items[28].Length - 2);
                    String price = bitmexApi.getBestPrice(symbol,side);
                    String opposite_side = "";
                    CurPriceTextBox.Text = "";
                    if (side == "Buy")
                    {
                        opposite_side = "Sell";
                    }
                    else if (side == "Sell")
                    {
                        opposite_side = "Buy";
                    }
                    else
                    {
                        MessageBox.Show("Side error: " + side);
                        return;
                    }
                    BitmexSay.Text = bitmexApi.PostLimitOrder(symbol, opposite_side, orderQty, price);
                    return;
                }
                string p = bitmexApi.getBestPrice(SymbolList.Text,SideList.Text);
                if (p != "error")
                {
                    CurPriceTextBox.Text = p;
                    BitmexSay.Text = bitmexApi.putOrderAmend(this.strategy1_orderID, p);
                }
            }

        }

        private void start1Button_Click(object sender, EventArgs e)
        {
            if (this.autoTrading1 ==true)
            {
                return;
            }
            String symbol = SymbolList.Text;
            String side = SideList.Text;
            String qty = Qty.Value.ToString();
            String type = "Limit";
            String json = bitmexApi.PostOrders(symbol, side, qty, type);
            BitmexSay.Text = json;
            List<string> fields = json.Split('"').ToList<string>();
            if (fields[1] == "error")
            {
                toolStripStatusLabel1.Text = side + " " + symbol + " Quantity:" + qty + " error occured";
                status.Refresh();
                return;
            }
            else
            {
                this.strategy1_orderID = fields[3];
            }
            CurPriceTextBox.Text = bitmexApi.recentTradePrice;
            this.autoTrading1 = true;
            rateTimer1.Start();
            //DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            toolStripStatusLabel1.Text = "Strategy 1 Auto trading started at " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            this.elapsedTime1 = 0;
            status.Refresh();
        }

        private void stop1Button_Click(object sender, EventArgs e)
        {
            rateTimer1.Stop();
            this.autoTrading1 = false;
            CurPriceTextBox.Text = "";
            toolStripStatusLabel1.Text = "";
            this.elapsedTime1 = 0;
            status.Refresh();
        }

        private void timerUpDown_ValueChanged(object sender, EventArgs e)
        {
            rateTimer1.Interval =(int) timerUpDown.Value;
            rateTimer2.Interval = (int)timerUpDown.Value;
        }

        private void ActionButton_Click(object sender, EventArgs e)
        {
            String action = ActionList.Text;
            switch (action)
            {
                case "GET/last order":
                    BitmexSay.Text = bitmexApi.GetLastOrder(SymbolList.Text,SideList.Text);
                    break;
                case "GET/last order orderID":
                    BitmexSay.Text = bitmexApi.GetLastOrder_orderID(SymbolList.Text, SideList.Text);
                    break;
                case "Display Recent Trade Price":
                    BitmexSay.Text = bitmexApi.getRecentTradePriceOneCoinJSON(SymbolList.Text);
                    break;
                case "Order Amend":
                    string id = bitmexApi.GetLastOrder_orderID(SymbolList.Text, SideList.Text);
                    string p = bitmexApi.getEntryPrice(SymbolList.Text);
                    BitmexSay.Text = bitmexApi.putOrderAmend(id,p);
                    break;
                case "Get 5 Level Order Book":
                    BitmexSay.Text = bitmexApi.GetOrderBook(SymbolList.Text, "5");
                    break;
                case "Liquidation":
                    BitmexSay.Text = bitmexApi.GetLiquidation(SymbolList.Text);
                    break;
                case "Get Open Position":
                    BitmexSay.Text = bitmexApi.GetOpenPositionQuantityJSON(SymbolList.Text);
                    break;
                case "Get Open Position Quantity":
                    BitmexSay.Text = bitmexApi.GetOpenPositionQuantity(SymbolList.Text);
                    break;
                case "Get Open Position maintMargin":
                    BitmexSay.Text = bitmexApi.GetOpenPositionMaintMarginJSON(SymbolList.Text);
                    break;
                case "Close One Position":
                    BitmexSay.Text = bitmexApi.CloseOnePosition(SymbolList.Text);
                    break;
                case "Add Margin To Position":
                    BitmexSay.Text = bitmexApi.AddMarginToPosition(SymbolList.Text);
                    break;
                case "Margin Balance Info":
                    BitmexSay.Text = bitmexApi.GetUserMargin();
                    break;
                case "Get Entry Price":
                    BitmexSay.Text = bitmexApi.getEntryPriceJSON(SymbolList.Text);
                    break;
                case "Wallet Ballance":
                    BitmexSay.Text = bitmexApi.GetXBTWalletBallance();
                    break;
                case "Reduceonly":
                    BitmexSay.Text = bitmexApi.PostOrderReduceonly(SymbolList.Text, SideList.Text, Qty.Value.ToString(), OrderTypeList.Text);
                    break;
                case "PostOrderClose":
                    BitmexSay.Text = bitmexApi.PostOrderClose(SymbolList.Text, SideList.Text, Qty.Value.ToString());
                    break;
                case "PostOrderParticipateDoNotInitiate":
                    break;
            }
        }

        private void TradeGroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void CancelAllOrdersButton_Click(object sender, EventArgs e)
        {
            BitmexSay.Text=bitmexApi.cancelAllOrders();
        }

        private void MainTimer_Tick(object sender, EventArgs e)
        {
            //CurPriceTextBox.Text = bitmexApi.getRecentTradePriceOneCoin(SymbolList.Text);
        }

        private void Start2Button_Click(object sender, EventArgs e)
        {
            if (this.autoTrading2== true)
            {
                return;
            }
            toolStripStatusLabel2.Text = "Filtering OrderBook....";
            status.Refresh();
            //BitmexSay.Text = "";
            //DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            String json = bitmexApi.GetOrderBook(SymbolList.Text,"0");
            List<string> items = json.Split('}').ToList<string>();
            int i = 0,j=0,total=items.Count;
            while (i < items.Count-1)
            {
                j++;
                String item = items[i].Substring(1);
                List<string> fields = item.Split(',').ToList<string>();
                String field;
                field = fields[3];
                List<string> ss = field.Split(':').ToList<string>();
                float size = float.Parse(ss[1]);
                float minSize =(float) MinOrderSize.Value;
                String side;
                field = fields[2];
                ss = field.Split(':').ToList<string>();
                side = ss[1];
                side = side.Substring(1, side.Length - 2);
                if (size > minSize && side==SideList.Text)
                {
                    float price;
                    field = fields[4];
                    ss = field.Split(':').ToList<string>();
                    price = float.Parse(ss[1]);
                    //MessageBox.Show(side);
                    switch (SymbolList.Text)
                    {
                        case "XBTUSD":
                            if (side == "Buy")
                            {
                                price += (float)0.5;
                            }
                            else if (side == "Sell")
                            {
                                price -= (float)0.5;
                            }
                            break;
                        default:
                            price =(float)Math.Round(price* 0.999,6);
                            break;
                    }
                    BitmexSay.Text =SymbolList.Text+ " order placed! Size:"+size+" Price:"+price;
                    BitmexSay.Text = bitmexApi.PostLimitOrder(SymbolList.Text, side, size.ToString(), price.ToString());
                    items = BitmexSay.Text.Split('"').ToList<string>();
                    if (items[1] == "error")
                    {
                        toolStripStatusLabel2.Text =side+" "+ SymbolList.Text+" Price:"+price+" Quantity:"+size+" error occured!";
                        status.Refresh();
                        return;
                    }
                    this.strategy2_orderID = items[3];
                    break;
                }
                i++;
            }
            /////////// for test mode -catch last order  ////////
            /*items =BitmexSay.Text.Split('"').ToList<string>();
            String item= items[28];
            item = item.Substring(1, item.Length - 2);
            double price = double.Parse(item);
            String side=items[21];
            if (side == "Buy")
            {
                price += (float)0.5;
            }
            else if (side == "Sell")
            {
                price -= (float)0.5;
            }
            item = items[26];
            item = item.Substring(1, item.Length - 2);
            long qty = long.Parse(item);
            String reply = bitmexApi.PostLimitOrder(SymbolList.Text, side, qty.ToString(), price.ToString());
            BitmexSay.Text = reply;
            items = reply.Split('"').ToList<string>();
            if (items[1] == "error")
            {
                toolStripStatusLabel1.Text = side + " " + SymbolList.Text + " Price:" + price + " Quantity:" + qty + " error occured!";
                status.Refresh();
                return;
            }
            this.strategy2_orderID = items[3];
            BitmexSay.Text = reply;*/
            /////////////////////  test mode end
            this.autoTrading2 =true;
            rateTimer2.Start();
            toolStripStatusLabel2.Text = "Strategy 2 auto trading started at " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            this.elapsedTime2 = 0;
            status.Refresh();
        }

        private void Stop2Button_Click(object sender, EventArgs e)
        {
            rateTimer2.Stop();
            this.autoTrading2 =false;
            CurPriceTextBox.Text = "";
            toolStripStatusLabel2.Text = "";
            this.elapsedTime2 = 0;
            status.Refresh();
        }

        private void ActionList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void CloseAllPositionsButton_Click(object sender, EventArgs e)
        {
            BitmexSay.Text = "";
            BitmexSay.Text = bitmexApi.CloseAllPositions();
        }

        private void OverOrdersButton_Click(object sender, EventArgs e)
        {
            BitmexSay.Text = bitmexApi.GetOverOrders(SymbolList.Text, MinOrderSize.Value.ToString(),SideList.Text);
        }
        private void email_send(string from, string password, string to, string server)
        {
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient(server);

                mail.From = new MailAddress(from);
                mail.To.Add(to);
                mail.Subject = "Test Mail";
                mail.Body = "This is for testing SMTP mail from GMAIL";

                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential(from, password);
                SmtpServer.EnableSsl = true;

                SmtpServer.Send(mail);
                MessageBox.Show("Mail Sent!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void gmail_send2me(string from, string password)
        {
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

                mail.From = new MailAddress(from);
                mail.To.Add("andrewzhang963@gmail.com");
                mail.Subject = "Test Mail";
                mail.Body = "This is for testing SMTP mail from GMAIL";

                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential(from, password);
                SmtpServer.EnableSsl = true;
                SmtpServer.DeliveryMethod = SmtpDeliveryMethod.Network;

                SmtpServer.Send(mail);
                MessageBox.Show("Mail Sent!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void testMailButton_Click(object sender, EventArgs e)
        {
        }

        private void rateTimer2_Tick(object sender, EventArgs e)
        {
            if (this.autoTrading2 == false)
            {
                return;
            }
            elapsedTime2 += rateTimer2.Interval / 1000;
            long second = elapsedTime2;
            long minute = second / 60;
            second = second % 60;
            long hour = minute / 60;
            minute = minute % 60;
            toolStripStatusLabel2.Text = "Strategy2 " + " Auto trading " + hour.ToString() + ":" + minute.ToString() + ":" + second.ToString();
            if (this.autoTrading2 == true)
            {
                //MessageBox.Show(this.strategy2_orderID);
                String order = bitmexApi.GetOrderByID(this.strategy2_orderID);
                BitmexSay.Text = order;
                List<string> items = order.Split('"').ToList<string>();
                String ordStatus = items[69];
                String leavesQty = items[84].Substring(1, items[84].Length - 2);
                String symbol = items[17];
                String side = items[21];
                String orderQty = items[26].Substring(1, items[26].Length - 2);
                String price = items[28].Substring(1, items[28].Length - 2);
                toolStripStatusLabel2.Text += " " + side + " " + price + " " + symbol + "" + orderQty + " " + ordStatus + " " + leavesQty + " remained";
                status.Refresh();
                switch (ordStatus)
                {
                    case "New":
                        BitmexSay.Text = bitmexApi.cancelOneOrder(this.strategy2_orderID);
                        rateTimer1.Stop();
                        this.autoTrading2 = false;
                        toolStripStatusLabel2.Text += " ...Order unfilling... Stopped!";
                        status.Refresh();
                        this.strategy2_orderID = "";
                        break;
                    case "PartiallyFilled":
                        break;
                    case "Filled":
                        rateTimer1.Stop();
                        this.autoTrading2 = false;
                        toolStripStatusLabel2.Text += " ...Order filled... Stopped!";
                        status.Refresh();
                        this.strategy2_orderID = "";
                        this.elapsedTime2 = 0;
                        break;
                }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void SymbolList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void OrderTypeList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Qty_ValueChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void BitmexSay_TextChanged(object sender, EventArgs e)
        {

        }

        private void status_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
