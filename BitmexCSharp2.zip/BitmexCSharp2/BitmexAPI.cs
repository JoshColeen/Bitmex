﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Linq;
using System.Windows.Forms;

namespace BitmexCSharp2
{
    public class OrderBookItem
    {
        public string Symbol { get; set; }
        public int Level { get; set; }
        public int BidSize { get; set; }
        public decimal BidPrice { get; set; }
        public int AskSize { get; set; }
        public decimal AskPrice { get; set; }
        public DateTime Timestamp { get; set; }
    }

    class BitmexAPI
    {
        public string domain = "https://testnet.bitmex.com";
        public string[] symbols;
        public string[] currency;
        public string apiKey;
        public string apiSecret;
        private int rateLimit;
        //private string lastOrderID;
        private int maxTry = 20;
        public string recentTradePrice;

        public BitmexAPI()
        {
            this.symbols = new string[8] { "XBTUSD", "ADAM19", "BCHM19", "EOSM19", "ETHXBT", "LTCM19", "TRXM19", "XRPM19" };
            this.currency = new string[9] {"XBT","ADA","BCH","EOS","ETH","LTC","TRX","XRP","XBK" };
            this.apiKey = "azUkIGbe2yJkvWYiGDQsM7-f";
            this.apiSecret = "KX5fLBCjW_eL3STV_chjFvmTZnrHXdtZQwxyl2tlhry5YrKG";
            //this.lastOrderID = "";
        }

        public BitmexAPI(string bitmexKey = "", string bitmexSecret = "", int rateLimit = 5000)
        {
            this.apiKey = bitmexKey;
            this.apiSecret = bitmexSecret;
            this.rateLimit = rateLimit;
            //this.lastOrderID = "";
        }

        private string BuildQueryData(Dictionary<string, string> param)
        {
            if (param == null)
                return "";

            StringBuilder b = new StringBuilder();
            foreach (var item in param)
                b.Append(string.Format("&{0}={1}", item.Key, WebUtility.UrlEncode(item.Value)));

            try { return b.ToString().Substring(1); }
            catch (Exception) { return ""; }
        }

        private string BuildJSON(Dictionary<string, string> param)
        {
            if (param == null)
                return "";

            var entries = new List<string>();
            foreach (var item in param)
                entries.Add(string.Format("\"{0}\":\"{1}\"", item.Key, item.Value));

            return "{" + string.Join(",", entries) + "}";
        }

        public static string ByteArrayToString(byte[] ba)
        {
            StringBuilder hex = new StringBuilder(ba.Length * 2);
            foreach (byte b in ba)
                hex.AppendFormat("{0:x2}", b);
            return hex.ToString();
        }

        private long GetExpires()
        {
            return DateTimeOffset.UtcNow.ToUnixTimeSeconds() + 3600; // set expires one hour in the future
        }

        private string Query(string method, string function, Dictionary<string, string> param = null, bool auth = false, bool json = false)
        {
            string paramData = json ? BuildJSON(param) : BuildQueryData(param);
            string url = "/api/v1" + function + ((method == "GET" && paramData != "") ? "?" + paramData : "");
            string postData = (method != "GET") ? paramData : "";

            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(domain + url);
            webRequest.Method = method;

            if (auth)
            {
                string expires = GetExpires().ToString();
                string message = method + url + expires + postData;
                byte[] signatureBytes = hmacsha256(Encoding.UTF8.GetBytes(apiSecret), Encoding.UTF8.GetBytes(message));
                string signatureString = ByteArrayToString(signatureBytes);

                webRequest.Headers.Add("api-expires", expires);
                webRequest.Headers.Add("api-key", apiKey);
                webRequest.Headers.Add("api-signature", signatureString);
            }

            try
            {
                if (postData != "")
                {
                    webRequest.ContentType = json ? "application/json" : "application/x-www-form-urlencoded";
                    var data = Encoding.UTF8.GetBytes(postData);
                    using (var stream = webRequest.GetRequestStream())
                    {
                        stream.Write(data, 0, data.Length);
                    }
                }

                using (WebResponse webResponse = webRequest.GetResponse())
                using (Stream str = webResponse.GetResponseStream())
                using (StreamReader sr = new StreamReader(str))
                {
                    return sr.ReadToEnd();
                }
            }
            catch (WebException wex)
            {
                using (HttpWebResponse response = (HttpWebResponse)wex.Response)
                {
                    if (response == null)
                        throw;

                    using (Stream str = response.GetResponseStream())
                    {
                        using (StreamReader sr = new StreamReader(str))
                        {
                            return sr.ReadToEnd();
                        }
                    }
                }
            }
        }
        public string GetUserMargin(){
            var param = new Dictionary<string, string>();
            string result = "";
            int i;
            for (i = 0; i < currency.Length; i++)
            {
                result += currency[i]+"\r\n";
                string json = Query("GET", "/user/margin", param, true);
                List<string> items = json.Split(',').ToList<string>();
                result += items[18] + "  " + items[19] + "  " + items[20] + "  " + items[21] + "  " + items[22] + "  " + items[23] + "\r\n";
                result += items[28] + "\r\n";
                result += items[32] + "  " + items[33] + "  " + items[34] + "  " + items[35] + "  " + items[36] + "  " + items[37] + "\r\n";
                result += items[29] + "  " + items[30] + "  " + items[29] + "  " + "\r\n";
            }
            return result;
        }
        public string GetXBTWalletBallance()
        {
            var param = new Dictionary<string, string>();
            string json = Query("GET", "/user/margin", param, true);
            List<string> items = json.Split(',').ToList<string>();
            string result = items[29];
            //items = result.Split(':').ToList<string>();
            return "0."+result.Split(':').ToList<string>()[1];
        }
        public string GetOrderBook(string symbol,string depth)
        {
            var param =new Dictionary<string, string>();
            param["symbol"] = symbol;
            param["depth"] = depth;
            return Query("GET", "/orderBook/L2", param, true);
        }

        public string GetOverOrders(string symbol, string quantity,string side)
        {
            String json = GetOrderBook(symbol, "0");
            List<string> items = json.Split('}').ToList<string>();
            int i = 0, j = 0, total = items.Count;
            while (i < items.Count - 1)
            {
                j++;
                String item = items[i].Substring(1);
                List<string> fields = item.Split(',').ToList<string>();
                String field;
                field = fields[3];
                List<string> ss = field.Split(':').ToList<string>();
                float size = float.Parse(ss[1]);
                float minSize = (float)Int32.Parse(quantity);
                field = fields[2];
                ss = field.Split(':').ToList<string>();
                field = ss[1];
                field = field.Substring(1, field.Length - 2);
                if (size < minSize || field!=side)
                {
                    items.RemoveAt(i);
                }
                else
                {
                    i++;
                }
            }
            i = 0;
            string str = "total " + (items.Count - 1) +"  "+ symbol + " orders over " + quantity + "\r\n";
            while (i < items.Count)
            {
                str += "\r\n" + items[i];
                i++;
            }
            return str;
        }
        public string GetOpenPositionQuantityJSON(string symbol)
        {
            var param = new Dictionary<string, string>();
            //param["symbol"] = symbol;
            param["filter"] =  "{ \"symbol\": \""+ symbol + "\"}";
            param["columns"] ="currentQty";
            return Query("GET", "/position", param, true);
        }
        public string GetOpenPositionQuantity(string symbol)
        {
            var param = new Dictionary<string, string>();
            //param["symbol"] = symbol;
            param["filter"] = "{ \"symbol\": \""+symbol+"\"}";
            param["columns"] = "currentQty";
            String json= Query("GET", "/position", param, true);
            List<string> items = json.Split(',').ToList<string>();
            String item = items[4];
            items=item.Split(':').ToList<string>();
            return items[1];
        }
        public string GetOpenPositionMaintMarginJSON(string symbol)
        {
            var param = new Dictionary<string, string>();
            //param["symbol"] = symbol;
            param["filter"] = "{ \"symbol\": \""+symbol+"\"}";
            param["columns"] = "maintMargin";
            return Query("GET", "/position", param, true);
        }
        public string AddMarginToPosition(string symbol)
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = symbol;
            String amount= GetOpenPositionQuantity(symbol);
            if (amount.Substring(0, 1) == "-")
            {
                amount = amount.Substring(1, amount.Length - 1);
            }
            param["amount"] = amount;
            return Query("POST", "/position/transferMargin", param, true);
        }
        public string CloseOnePosition(string symbol)
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = symbol;
            param["ordType"] = "Market";
            param["execInst"] = "Close";
            return Query("POST", "/order", param, true);
        }
        public string CloseAllPositions()
        {
            int i;
            string reply = "";
            for (i = 0; i < symbols.Length; i++)
            {
                reply+=CloseOnePosition(symbols[i])+"\r\n";
            }
            return reply;
        }
        public string GetLiquidation(string symbol)
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = symbol;
            return Query("GET", "/liquidation", null, true);
        }
        //public List<OrderBookItem> GetOrderBook(string symbol, int depth)
        //{
        //    var param = new Dictionary<string, string>();
        //    param["symbol"] = symbol;
        //    param["depth"] = depth.ToString();
        //    string res = Query("GET", "/orderBook", param);
        //    return JsonSerializer.DeserializeFromString<List<OrderBookItem>>(res);
        //}

        public string GetOrders()
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = "XBTUSD";
            //param["filter"] = "{\"open\":true}";
            //param["columns"] = "";
            //param["count"] = 100.ToString();
            //param["start"] = 0.ToString();
            //param["reverse"] = false.ToString();
            //param["startTime"] = "";
            //param["endTime"] = "";
            return Query("GET", "/order", param, true);
        }

        public string GetLastOrder(String symbol,String side)
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = symbol;
            param["side"] = side;
            param["reverse"] = "true";
            param["count"] = "1";
            return Query("GET", "/order", param, true);
        }

        public string GetLastOrder_orderID(String symbol, String side)
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = symbol;
            param["side"] = side;
            param["reverse"] = "true";
            param["count"] = "1";
            param["columns"] = "orderID";
            String json= Query("GET", "/order", param, true);
            List<string> items= json.Split(',').ToList<string>();
            String item = items[0];
            items = item.Split('"').ToList<string>();
            item = items[3];
            return item;
        }
        public string GetOrderByID(String orderID)
        {
            var param = new Dictionary<string, string>();
            //param["orderID"] = orderID;
            param["filter"] = "{ \"orderID\": \""+orderID+"\"}";
            return Query("GET", "/order", param, true);
        }
        public string PostOrders()// original
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = "XBTUSD";
            param["side"] = "Sell";
            param["orderQty"] = "200";
            param["ordType"] = "Market";
            return Query("POST", "/order", param, true);
        }

        public string PostLimitOrder(String symbol,String side,String qty, String price)
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = symbol;
            param["side"] = side;
            param["orderQty"] = qty;
            param["ordType"] = "Limit";
            param["price"] = price;
            return Query("POST", "/order", param, true);
        }
        public string PostOrders(String symbol, String side, String qty, String type)
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = symbol;
            param["side"] = side;
            param["orderQty"] = qty;
            param["ordType"] = type;
            if (type == "Limit")
            {
                String price = this.getBestPrice(symbol, side);
                param["price"] = price;
            }
            String order_data;
            order_data = Query("POST", "/order", param, true);
            return order_data;
        }
        public string PostOrderReduceonly(String symbol, String side, String qty, String type)
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = symbol;
            param["side"] = side;
            param["orderQty"] = qty;
            param["ordType"] = type;
            param["execInst"] = "ReduceOnly";
            if (type == "Limit")
            {
                String price = this.getBestPrice(symbol, side);
                param["price"] = price;
            }
            String order_data;
            order_data = Query("POST", "/order", param, true);
            return order_data;
        }
        public string PostOrderLimitTrailingstop(String symbol, String side, String qty, String price, String peg)
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = symbol;
            param["side"] = side;
            param["orderQty"] = qty;
            param["price"] = price;
            param["pegOffsetValue"] = peg;
            param["pegPriceType"] = "TrailingStopPeg";
            param["ordType"] = "StopLimit";
            String order_data;
            order_data = Query("POST", "/order", param, true);
            return order_data;
        }
        public string PostOrderClose(String symbol, String side, String qty)
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = symbol;
            param["side"] = side;
            param["orderQty"] = qty;
            param["execInst"] = "Close";
            String order_data;
            order_data = Query("POST", "/order", param, true);
            return order_data;
        }
        public string PostOrderParticipateDoNotInitiate(String symbol, String side, String qty, String price)
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = symbol;
            param["side"] = side;
            param["orderQty"] = qty;
            param["price"] = price;
            param["ordType"] = "Limit";
            param["execInst"] = "ParticipateDoNotInitiate";
            String order_data;
            order_data = Query("POST", "/order", param, true);
            return order_data;
        }
        public string PostOrder(String symbol, String side, String qty, String price, String stopPx="",String pegOffsetValue="", String pegPriceType="",String ordType="", String execInst="")
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = symbol;
            param["side"] = side;
            param["orderQty"] = qty;
            param["price"] = price;
            param["stopPx"] = stopPx;
            param["pegOffsetValue"] = pegOffsetValue;
            param["pegPriceType"] = pegPriceType;
            param["ordType"] = ordType;
            param["execInst"] = execInst;
            String order_data;
            order_data = Query("POST", "/order", param, true);
            return order_data;
        }
        public string getRecentTradePriceOneCoinJSON(String symbol)
        {
            var param =new Dictionary<string, string>();
            param["symbol"] = symbol;
            param["columns"]="price";
            param["count"] = "1";
            param["reverse"] = "true";
            return Query("GET", "/trade", param, true);
        }

        public string getRecentTradePriceOneCoin(String symbol)
        {
            String json = getRecentTradePriceOneCoinJSON(symbol);
            List<string> items = json.Split(',').ToList<string>();
            String item = items[2];
            items = item.Split(':').ToList<string>();
            item= items[1];
            items = item.Split('}').ToList<string>();
            item = items[0];
            this.recentTradePrice = item;
            return item;
        }
        public string getEntryPriceJSON(string symbol)
        {
            var param = new Dictionary<string, string>();
            param["filter"] = "{ \"symbol\": \"" + symbol + "\"}";
            param["columns"] = "avgEntryPrice";
            return Query("GET", "/position", param, true);
        }
        public string getEntryPrice(string symbol)
        {
            string json = this.getEntryPriceJSON(symbol);
            List<string> items = json.Split(',').ToList<string>();
            if (items.Count < 7)
            {
                return "error";
            }
            String item = items[7];
            items = item.Split(':').ToList<string>();
            item = items[1];
            items = item.Split('}').ToList<string>();
            item = items[0];
            return item;
        }
        public string getBestPrice(string symbol,string side)
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = symbol;
            param["depth"] = "1";
            int i=0;
            List<string> items= new List<string>();
            while (items.Count != 10 && i<this.maxTry)
            {
                string json = Query("GET", "/orderBook/L2", param, true);
                items = json.Split(',').ToList<string>();
                i++;
                if (items.Count != 10)
                {
                    System.Threading.Thread.Sleep(2000);
                }
                if (i == this.maxTry)
                {
                    MessageBox.Show("Server not respond!");
                    System.Environment.Exit(0);
                }
            }
            string item="";
            if (side == "Sell")
            {
                item = items[4];
            }
            else if (side == "Buy")
            {
                item = items[9];
            }
            items = item.Split(':').ToList<string>();
            item = items[1];//11822},
            items = item.Split('}').ToList<string>();
            item = items[0];
            return item;
            /*List<string> items = json.Split('{').ToList<string>();
            string item = "";
            if (side == "Sell")
            {
                item = items[1];
            }
            else if (side == "Buy")
            {
                item = items[2];
            }
            items = item.Split(',').ToList<string>();
            item = items[4];//"price": 11822},
            items = item.Split(':').ToList<string>();
            item = items[1];//11822},
            items = item.Split('}').ToList<string>();
            item = items[0];
            return item;*/
        }
        public string putOrderAmend(String OrderID,string price)
        {
            var param = new Dictionary<string, string>();
            //param["symbol"] = symbol;
            //param["side"] = side;
            param["orderID"] = OrderID; //GetLastOrder_orderID(symbol, side);
            //string price= getEntryPrice(symbol);
            //if (price == "error")
            //{
            //    return "error";
            //}
            param["price"] = price;
            return Query("PUT", "/order", param, true);
        }

        public string cancelAllOrders()
        {
            var param = new Dictionary<string, string>();
            return Query("DELETE", "/order/all",param,true);
        }
        public string cancelOneOrder(String OrderID)
        {
            var param = new Dictionary<string, string>();
            param["orderID"] = OrderID;
            return Query("DELETE", "/order", param, true);
        }
        public string setLeverage(String symbol,String lev)
        {
            var param = new Dictionary<string, string>();
            param["symbol"] = symbol;
            param["leverage"] = lev;
            return Query("POST", "/position/leverage", param, true);
        }

        public string DeleteOrders()
        {
            var param = new Dictionary<string, string>();
            param["orderID"] = "de709f12-2f24-9a36-b047-ab0ff090f0bb";
            param["text"] = "cancel order by ID";
            return Query("DELETE", "/order", param, true, true);
        }

        private byte[] hmacsha256(byte[] keyByte, byte[] messageBytes)
        {
            using (var hash = new HMACSHA256(keyByte))
            {
                return hash.ComputeHash(messageBytes);
            }
        }

        #region RateLimiter

        private long lastTicks = 0;
        private object thisLock = new object();

        private void RateLimit()
        {
            lock (thisLock)
            {
                long elapsedTicks = DateTime.Now.Ticks - lastTicks;
                var timespan = new TimeSpan(elapsedTicks);
                if (timespan.TotalMilliseconds < rateLimit)
                    Thread.Sleep(rateLimit - (int)timespan.TotalMilliseconds);
                lastTicks = DateTime.Now.Ticks;
            }
        }

        #endregion RateLimiter
    }
}
